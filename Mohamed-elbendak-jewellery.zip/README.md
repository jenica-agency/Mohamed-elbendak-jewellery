# Mohamed-elbendak-jewellery
static landing page 
